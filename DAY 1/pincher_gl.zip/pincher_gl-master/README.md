pincher_gl
==========
To start the simulator run: openGL_main_pyGame. <br>
This program requires python pygame,numpy, and opengl modules.<br> 
Press the left mouse button and w to move camera forward, q move left, e to move right, s to move backward.<br>
To manually move the robots joints press F1, 1, F2, 2, F3, 3 F4, 4. <br>
To open and close the grippers press a and d. <br>
The space bar moves the robot through sequences that pounce ball, pick ball, move up, drop ball, release, start over.<br>
If the robot can not reach the ball you may have to press the space bar a few times and it will change the wrist angle, so it can reach.<br>
