this program requires python pygame,numpy, and opengl modules
press the left mouse button and w to move camera forward, q move left, e to move right, s to move backward.
to manually move the robots joints press F1, 1, F2, 2, F3, 3 F4, 4
to open and close the grippers press a and d
the space bar moves the robot through sequences that pounce ball, pick ball, move up, drop ball, release, start over